import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.lang.Math;
import java.util.*;

public class sim {
	public static void main(String[] args) throws IOException {

		String countername = args[0];
		int stepbit = Integer.parseInt(args[1]);
		File fileName = new File(args[args.length - 1]);
		Scanner inputFileName = new Scanner(fileName);
		ArrayList<String> therealone = new ArrayList<>();
		ArrayList<String> procounter = new ArrayList<>();
		while (inputFileName.hasNext()) {
			String word = inputFileName.next();
			if (word.length() == 1)
				therealone.add(word);
			else
				procounter.add(word);
		}
		int correct = 0;
		char prediction = 'a';

	    if (countername.equals("smith")) {

		int staticaccumulator = 0;
		if (stepbit == 1)
			staticaccumulator = 1;
		else if (stepbit == 2)
			staticaccumulator = 2;
		else if (stepbit == 3)
			staticaccumulator = 4;
		else
			staticaccumulator = 8;
		for (int i = 0; i < therealone.size(); i++) {
			if (stepbit == 1) {
				if (staticaccumulator > 0)
					prediction = 't';
				else
					prediction = 'n';
			} else if (stepbit == 2) {
				if (staticaccumulator > 1)
					prediction = 't';
				else
					prediction = 'n';
			} else if (stepbit == 3) {
				if (staticaccumulator > 3)
					prediction = 't';
				else
					prediction = 'n';
			} else {
				if (staticaccumulator > 7)
					prediction = 't';
				else
					prediction = 'n';
			}
			if (therealone.get(i).charAt(0) == prediction)
				correct++;
			if (therealone.get(i).charAt(0) == 't') {
				if (stepbit == 1 && staticaccumulator != 1)
					staticaccumulator++;
				else if (stepbit == 2 && staticaccumulator != 3)
					staticaccumulator++;
				else if (stepbit == 3 && staticaccumulator != 7)
					staticaccumulator++;
				else if (stepbit == 4 && staticaccumulator != 15)
					staticaccumulator++;
			} else if (staticaccumulator != 0)
				staticaccumulator--;
		}
		int mistaken = therealone.size() - correct;
		double rate = mistaken * 100.00 / therealone.size();
		System.out.println("COMMAND");
		System.out.println("./sim smith " + stepbit + " " + fileName);
		System.out.println("OUTPUT");
		System.out.println("number of predictions:          " + therealone.size());
		System.out.println("number of mispredictions:       " + mistaken);
		System.out.println("misprediction rate:             " + String.format("%.2f", rate) + "%");
		System.out.println("FINAL COUNTER CONTENT:          " + staticaccumulator);
	}

	if (countername.equals("bimodal")) {

		HashMap<Integer, Integer> firstCounter = new HashMap<>();
		for (int i = 0; i < Math.pow(2, stepbit); i++)
			firstCounter.put(i, 4);
		for (int i = 0; i < therealone.size(); i++) {
			int var = stepbit;
			int decAddress = Integer.parseInt(procounter.get(i), 16);
			decAddress = decAddress >> 2;
			StringBuilder sb = new StringBuilder();
			while (var > 0) {
				sb.append((decAddress & 1));
				decAddress = decAddress >> 1;
				var--;
			}
			String ab = sb.reverse().toString();
			int ind = Integer.parseInt(ab, 2);
			if (firstCounter.get(ind) > 3)
				prediction = 't';
			else
				prediction = 'n';
			if (therealone.get(i).charAt(0) == prediction)
				correct++;
			if (therealone.get(i).charAt(0) == 't' && firstCounter.get(ind) != 7)
				firstCounter.put(ind, firstCounter.get(ind) + 1);
			else if (therealone.get(i).charAt(0) == 'n' && firstCounter.get(ind) != 0)
				firstCounter.put(ind, firstCounter.get(ind) - 1);
		}
		int mistaken = therealone.size() - correct;
		double rate = mistaken * 100.00 / therealone.size();
		System.out.println("COMMAND");
		System.out.println("./sim bimodal " + stepbit + " " + fileName);
		System.out.println("OUTPUT");
		System.out.println("number of predictions:          " + therealone.size());
		System.out.println("number of mispredictions:       " + mistaken);
		System.out.println("misprediction rate:             " + String.format("%.2f", rate) + "%");
		System.out.println("FINAL BIMODAL CONTENTS");
		for (int i = 0; i < firstCounter.size(); i++) {
			System.out.println(i + "      " + firstCounter.get(i));
		}

	}

	if (countername.equals("gshare")) {

		int ghrBits = Integer.parseInt(args[2]);
		int ghrVar = 0;

		StringBuilder stringBuilder2 = new StringBuilder();
		stringBuilder2.append('1');
		for (int i = 1; i < ghrBits; i++)
			stringBuilder2.append('0');
		String tempVar = stringBuilder2.toString();
		int maskVar1 = Integer.parseInt(tempVar, 2);

		StringBuilder stringBuilder3 = new StringBuilder();
		stringBuilder2.append('0');
		for (int i = 1; i < ghrBits; i++)
			stringBuilder2.append('1');
		String tempVar2 = stringBuilder2.toString();
		int maskVar2 = Integer.parseInt(tempVar2, 2);

		HashMap<Integer, Integer> firstCounter = new HashMap<>();
		for (int i = 0; i < Math.pow(2, stepbit); i++)
			firstCounter.put(i, 4);
		for (int i = 0; i < therealone.size(); i++) {
			int var = stepbit;
			int decAddress = Integer.parseInt(procounter.get(i), 16);
			decAddress = decAddress >> 2;
			StringBuilder stringBuilder = new StringBuilder();
			while (var > 0) {
				stringBuilder.append((decAddress & 1));
				decAddress = decAddress >> 1;
				var--;
			}
			String ab = stringBuilder.reverse().toString();
			int ind = Integer.parseInt(ab, 2);
			ind = ind ^ ghrVar;
			ghrVar = ghrVar >> 1;
			if (firstCounter.get(ind) > 3)
				prediction = 't';
			else
				prediction = 'n';
			if (therealone.get(i).charAt(0) == prediction)
				correct++;
			if (therealone.get(i).charAt(0) == 't') {
				ghrVar = ghrVar | maskVar1;
				if (firstCounter.get(ind) != 7)
					firstCounter.put(ind, firstCounter.get(ind) + 1);
			} else {
				ghrVar = ghrVar & maskVar2;
				if (firstCounter.get(ind) != 0)
					firstCounter.put(ind, firstCounter.get(ind) - 1);
			}
		}
		int mistaken = therealone.size() - correct;
		double rate = mistaken * 100.00 / therealone.size();
		System.out.println("COMMAND");
		System.out.println("./sim gshare " + stepbit + " " + ghrBits + " " + fileName);
		System.out.println("OUTPUT");
		System.out.println("number of predictions:          " + therealone.size());
		System.out.println("number of mispredictions:       " + mistaken);
		System.out.println("misprediction rate:             " + String.format("%.2f", rate) + "%");
		System.out.println("FINAL GSHARE CONTENTS");
		for (int i = 0; i < firstCounter.size(); i++) {
			System.out.println(i + "      " + firstCounter.get(i));
		}
	}

	if (countername.equals("hybrid")) {

		int Tcount = 0;
		int mistaken = 0;

		String gsharestr = "";

		int gmbits = Integer.parseInt(args[2]);
		int gnbits = Integer.parseInt(args[3]);
		int bmbbits = Integer.parseInt(args[4]);
		
		int bSize = (int) Math.pow(2, bmbbits);
		int gSize = (int) Math.pow(2, gmbits);
		int hSize = (int) Math.pow(2, stepbit);

		int[] Hybridarray = new int[hSize];
		int[] Gsharearray = new int[gSize];
		int[] Bimodalarray = new int[bSize];

		Arrays.fill(Gsharearray, 4);
		Arrays.fill(Bimodalarray, 4);
		Arrays.fill(Hybridarray, 1);

		for (int i = 0; i < gnbits; i++) {
			gsharestr = gsharestr + "0";
		}

		try {
			Scanner myReader = new Scanner(fileName);
			while (myReader.hasNextLine()) {
				Tcount = Tcount + 1;
				String data1 = myReader.nextLine();
				String[] data = data1.split(" ");
				String income = data[1];
				int h_dec = Integer.parseInt(data[0], 16);
				String h_bin = Integer.toBinaryString(h_dec);
				String h_bin_index = h_bin.substring(h_bin.length() - 2 - stepbit, h_bin.length() - 2);
				int h_index = Integer.parseInt(h_bin_index, 2);

				int b_dec = Integer.parseInt(data[0], 16);
				String b_bin = Integer.toBinaryString(b_dec);
				String b_bin_index = b_bin.substring(b_bin.length() - 2 - bmbbits, b_bin.length() - 2);
				int b_index = Integer.parseInt(b_bin_index, 2);
				String b_pred = "";
				if (Bimodalarray[b_index] < 4) {
					b_pred = "n";
				} else {
					b_pred = "t";
				}
				
				String g_pred = "";
				int g_dec = Integer.parseInt(data[0], 16);
				String g_bin = Integer.toBinaryString(g_dec);
				String g_ind1 = g_bin.substring(g_bin.length() - 2 - gmbits, g_bin.length() - 2 - gnbits);
				String g_find_ind2 = g_bin.substring(g_bin.length() - 2 - gnbits, g_bin.length() - 2);
				String g_ind2 = "";
				String[] gs_gshare = gsharestr.split("");
				String[] gs_find_ind2 = g_find_ind2.split("");
				int l = gs_gshare.length;
				for (int i = 0; i < l; i++) {
					if (gs_find_ind2[i].equals(gs_gshare[i])) {
						g_ind2 = g_ind2 + "0";
					} else {
						g_ind2 = g_ind2 + "1";
					}
				}
				String g_bin_ind = g_ind1 + g_ind2;
				int g_index = Integer.parseInt(g_bin_ind, 2);
				if (Gsharearray[g_index] < 4) {
					g_pred = "n";
				} else {
					g_pred = "t";
				}
				
				if (Hybridarray[h_index] >= 2) {
					if (!income.equals(g_pred)) {
						mistaken = mistaken + 1;
					}
					
					if (income.equals("t")) {
						if (Gsharearray[g_index] != 7) {
							Gsharearray[g_index] = Gsharearray[g_index] + 1;
						}
					} else {
						if (Gsharearray[g_index] != 0) {
							Gsharearray[g_index] = Gsharearray[g_index] - 1;
						}
					}
					
				} else {
					if (!income.equals(b_pred)) {
						mistaken = mistaken + 1;
					}
					
					if (income.equals("t")) {
						if (Bimodalarray[b_index] != 7) {
							Bimodalarray[b_index] = Bimodalarray[b_index] + 1;
						}
					} else {
						if (Bimodalarray[b_index] != 0) {
							Bimodalarray[b_index] = Bimodalarray[b_index] - 1;
						}
						
					}
				}
				
				if (income.equals("t")) {
					gsharestr = "1" + gsharestr;
				} else {
					gsharestr = "0" + gsharestr;
				}
				gsharestr = gsharestr.substring(0, gsharestr.length() - 1);
				
				if (b_pred.equals(income) && !g_pred.equals(income)) {
					if (Hybridarray[h_index] != 0) {
						Hybridarray[h_index] = Hybridarray[h_index] - 1;
					}
				}
				if (!b_pred.equals(income) && g_pred.equals(income)) {
					if (Hybridarray[h_index] != 3) {
						Hybridarray[h_index] = Hybridarray[h_index] + 1;
					}
				}
				
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error");
			e.printStackTrace();
		}
		
		double val = (((double) mistaken / (double) Tcount) * 10000.0);
		double rate = Math.round(val) / 100.0;
		
		System.out.println("COMMAND");
		System.out.println("./sim hybrid " + stepbit +" " + gmbits + " " + gnbits + " " + bmbbits + " " + fileName);
		System.out.println("OUTPUT");
		System.out.println("number of prediction      :" + Tcount);
		System.out.println("number of misprediction   :" + mistaken);
		System.out.println("misprediction rate        :" + rate + "%");
		
		System.out.println("FINAL CHOOSER CONTENTS");
		for (int i = 0; i < Hybridarray.length; i++) {
			System.out.println(i + "   " + Hybridarray[i]);
		}
		
		System.out.println("FINAL GSHARE CONTENTS");
		for (int i = 0; i < Gsharearray.length; i++) {
			System.out.println(i + "   " + Gsharearray[i]);
		}

		System.out.println("FINAL BIMODAL CONTENTS");
		for (int i = 0; i < Bimodalarray.length; i++) {
			System.out.println(i + "   " + Bimodalarray[i]);
		}

	}
	}}
